package example;

public enum Color {
  BLACK,
  RED,
  BLUE,
  GREEN,
  WHITE,
  TEAL,
  CHARTREUSE,
  PUCE,
}

