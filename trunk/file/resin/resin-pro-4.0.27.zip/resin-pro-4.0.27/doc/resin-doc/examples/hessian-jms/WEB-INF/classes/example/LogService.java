package example;

public interface LogService {
  public void log(String message);
  public String getLog();
}
