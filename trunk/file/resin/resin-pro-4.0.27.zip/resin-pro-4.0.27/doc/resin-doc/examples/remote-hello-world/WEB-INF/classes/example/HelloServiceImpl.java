package example;

public class HelloServiceImpl implements HelloService
{
  /**
   * Returns "hello, world".
   */
  public String hello()
  {
    return "hello, world";
  }
}
