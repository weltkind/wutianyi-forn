package example;

public interface HelloService {
  /**
   * Returns "hello, world".
   */
  public String hello();
}
