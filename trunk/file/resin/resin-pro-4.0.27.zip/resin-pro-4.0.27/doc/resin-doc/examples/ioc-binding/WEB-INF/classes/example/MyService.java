package example;

public interface MyService {
  public void setMessage(String message);
  
  public String getMessage();
}