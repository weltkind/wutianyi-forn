//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by iis_srun.rc
//
#define IDS_SERVER                      102

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         103
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
